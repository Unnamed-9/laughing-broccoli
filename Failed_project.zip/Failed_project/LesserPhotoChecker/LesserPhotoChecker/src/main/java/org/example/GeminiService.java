package org.example;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.util.Base64;

public class GeminiService {

    // Try models in order — flash-lite has a separate free quota from flash
    private static final String[] MODELS = {
        "gemini-2.0-flash",
        "gemini-2.0-flash-lite",
        "gemini-1.5-flash-8b"
    };

    public static String analyzeImage(byte[] imageBytes, String mimeType) throws Exception {
        String apiKey = System.getenv("GEMINI_API_KEY");

        if (apiKey == null || apiKey.isBlank()) {
            return "nature animal object photo";
        }

        if (mimeType == null || mimeType.isBlank()) mimeType = "image/jpeg";

        String base64Image = Base64.getEncoder().encodeToString(imageBytes);
        String requestBodyJson = buildRequestBody(base64Image, mimeType);

        HttpClient client = HttpClient.newHttpClient();

        for (String model : MODELS) {
            String url = "https://generativelanguage.googleapis.com/v1beta/models/"
                    + model + ":generateContent?key=" + apiKey;

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBodyJson))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 429) {
                System.err.println("Model " + model + " quota exhausted, trying next...");
                continue; // try next model
            }

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                System.err.println("Gemini API error " + response.statusCode() + " on " + model + ": " + response.body());
                continue;
            }

            JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
            JsonArray candidates = json.getAsJsonArray("candidates");
            if (candidates == null || candidates.isEmpty()) continue;

            JsonObject candidate = candidates.get(0).getAsJsonObject();
            if (!candidate.has("content")) continue;

            JsonArray parts = candidate.getAsJsonObject("content").getAsJsonArray("parts");
            if (parts == null || parts.isEmpty()) continue;

            return parts.get(0).getAsJsonObject()
                    .get("text").getAsString()
                    .replace("\n", " ")
                    .trim();
        }

        // All models exhausted — fall back to generic keywords
        System.err.println("All Gemini models quota-exhausted. Using fallback keywords.");
        return "nature animal object photo";
    }

    private static String buildRequestBody(String base64Image, String mimeType) {
        JsonObject inlineData = new JsonObject();
        inlineData.addProperty("mime_type", mimeType);
        inlineData.addProperty("data", base64Image);

        JsonObject imagePart = new JsonObject();
        imagePart.add("inline_data", inlineData);

        JsonObject textPart = new JsonObject();
        textPart.addProperty("text",
            "Look at this image and return only 3 to 6 simple English search keywords describing its main topic. No sentence, no punctuation, just keywords separated by spaces.");

        JsonArray parts = new JsonArray();
        parts.add(textPart);
        parts.add(imagePart);

        JsonObject content = new JsonObject();
        content.add("parts", parts);

        JsonArray contents = new JsonArray();
        contents.add(content);

        JsonObject body = new JsonObject();
        body.add("contents", contents);
        return body.toString();
    }
}
