package org.example;

public class ImageResult {
    public String title;
    public String imageUrl;
    public int score;

    public ImageResult(String title, String imageUrl, int score) {
        this.title = title;
        this.imageUrl = imageUrl;
        this.score = score;
    }
}
