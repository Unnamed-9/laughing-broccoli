package org.example;

import com.google.gson.*;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class WikimediaService {

    public static List<ImageResult> searchImages(String query) throws Exception {
        String unsplashKey = System.getenv("UNSPLASH_ACCESS_KEY");

        if (unsplashKey != null && !unsplashKey.isBlank()) {
            return searchUnsplash(query, unsplashKey);
        }

        // Fallback to Wikimedia if no Unsplash key provided
        return searchWikimedia(query);
    }

    private static List<ImageResult> searchUnsplash(String query, String accessKey) throws Exception {
        List<ImageResult> results = new ArrayList<>();
        String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);

        String url = "https://api.unsplash.com/search/photos" +
                "?query=" + encodedQuery +
                "&per_page=40" +
                "&orientation=landscape";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Client-ID " + accessKey)
                .header("Accept-Version", "v1")
                .GET()
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            System.err.println("Unsplash API error: " + response.statusCode() + " — " + response.body());
            return results;
        }

        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        JsonArray photos = json.getAsJsonArray("results");
        if (photos == null) return results;

        for (JsonElement el : photos) {
            try {
                JsonObject photo = el.getAsJsonObject();
                String imageUrl = photo.getAsJsonObject("urls").get("regular").getAsString();
                JsonObject user = photo.getAsJsonObject("user");
                String description = photo.has("description") && !photo.get("description").isJsonNull()
                        ? photo.get("description").getAsString()
                        : user.get("name").getAsString();
                results.add(new ImageResult(description, imageUrl, 0));
            } catch (Exception e) {
                // skip malformed entries
            }
        }

        return results;
    }

    private static List<ImageResult> searchWikimedia(String query) throws Exception {
        List<ImageResult> results = new ArrayList<>();
        String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);

        String url = "https://commons.wikimedia.org/w/api.php" +
                "?action=query" +
                "&generator=search" +
                "&gsrsearch=" + encodedQuery +
                "&gsrnamespace=6" +
                "&gsrlimit=40" +
                "&prop=imageinfo" +
                "&iiprop=url%7Cmime" +
                "&format=json" +
                "&origin=*";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("User-Agent", "LesserPhotoCheckerStudentProject/1.0 (educational)")
                .GET()
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            System.err.println("Wikimedia API error: " + response.statusCode());
            return results;
        }

        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        if (!json.has("query")) return results;

        JsonObject queryObj = json.getAsJsonObject("query");
        if (!queryObj.has("pages")) return results;

        JsonObject pages = queryObj.getAsJsonObject("pages");
        for (String key : pages.keySet()) {
            try {
                JsonObject page = pages.getAsJsonObject(key);
                if (!page.has("imageinfo")) continue;

                String title = page.get("title").getAsString();
                JsonArray imageInfoArray = page.getAsJsonArray("imageinfo");
                if (imageInfoArray == null || imageInfoArray.isEmpty()) continue;

                JsonObject imageInfo = imageInfoArray.get(0).getAsJsonObject();
                if (!imageInfo.has("url")) continue;

                String imageUrl = imageInfo.get("url").getAsString();
                if (imageUrl.matches("(?i).*\\.(jpg|jpeg|png|gif|webp)$")) {
                    results.add(new ImageResult(title, imageUrl, 0));
                }
            } catch (Exception e) {
                // skip malformed entries
            }
        }

        return results;
    }
}
