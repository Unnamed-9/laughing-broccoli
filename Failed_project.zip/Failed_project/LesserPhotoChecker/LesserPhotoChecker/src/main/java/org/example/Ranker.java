package org.example;

import java.util.*;

public class Ranker {
    public static List<ImageResult> rank(String query, List<ImageResult> results) {
        HashMap<String, ImageResult> uniqueResults = new HashMap<>();

        for (ImageResult result : results) {
            int score = EditDistance.calculate(query, result.title);
            result.score = score;
            uniqueResults.put(result.imageUrl, result);
        }

        PriorityQueue<ImageResult> minHeap = new PriorityQueue<>(Comparator.comparingInt(r -> r.score));
        minHeap.addAll(uniqueResults.values());

        List<ImageResult> best = new ArrayList<>();
        int limit = Math.min(12, minHeap.size());
        for (int i = 0; i < limit; i++) best.add(minHeap.poll());
        return best;
    }
}
