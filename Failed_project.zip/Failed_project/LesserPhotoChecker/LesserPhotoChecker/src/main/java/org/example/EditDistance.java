package org.example;

public class EditDistance {
    public static int calculate(String a, String b) {
        a = clean(a);
        b = clean(b);

        // If either is empty after cleaning, return the other's length
        if (a.isEmpty()) return b.length();
        if (b.isEmpty()) return a.length();

        int[][] dp = new int[a.length() + 1][b.length() + 1];

        for (int i = 0; i <= a.length(); i++) dp[i][0] = i;
        for (int j = 0; j <= b.length(); j++) dp[0][j] = j;

        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = 1 + Math.min(
                            dp[i - 1][j - 1],
                            Math.min(dp[i - 1][j], dp[i][j - 1])
                    );
                }
            }
        }
        return dp[a.length()][b.length()];
    }

    static String clean(String text) {
        if (text == null) return "";
        return text.toLowerCase()
                .replace("file:", "")
                // Remove file extensions before scoring
                .replaceAll("\\.(jpg|jpeg|png|gif|webp|svg|tiff?|bmp)$", "")
                .replaceAll("[^a-z0-9 ]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }
}
