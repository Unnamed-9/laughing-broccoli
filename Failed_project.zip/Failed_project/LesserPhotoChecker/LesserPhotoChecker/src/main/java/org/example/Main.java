package org.example;

import io.javalin.Javalin;
import io.javalin.http.UploadedFile;

import java.awt.Desktop;
import java.net.URI;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Javalin app = Javalin.create(config -> config.http.maxRequestSize = 20_000_000).start(7070);

        app.get("/", ctx -> ctx.html(homePage()));

        app.post("/search", ctx -> {
            UploadedFile file = ctx.uploadedFile("image");
            if (file == null) {
                ctx.html("<h2>No image uploaded.</h2><a href='/'>Go back</a>");
                return;
            }

            byte[] imageBytes = file.content().readAllBytes();
            String mimeType = file.contentType();

            String topic = GeminiService.analyzeImage(imageBytes, mimeType);
            List<ImageResult> internetImages = WikimediaService.searchImages(topic);
            List<ImageResult> rankedImages = Ranker.rank(topic, internetImages);

            ctx.html(resultsPage(topic, rankedImages));
        });

        try {
            Desktop.getDesktop().browse(new URI("http://localhost:7070"));
        } catch (Exception e) {
            System.out.println("Open manually: http://localhost:7070");
        }
    }

    private static String homePage() {
        return """
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Lesser Photo Checker</title>
                    <style>
                        body { font-family: Arial; background: linear-gradient(135deg, #ddeeff, #ffffff); text-align: center; padding: 45px; }
                        .box { background: white; width: 650px; margin: auto; padding: 35px; border-radius: 18px; box-shadow: 0 0 18px rgba(0,0,0,0.22); }
                        .drop { border: 3px dashed #2878d8; padding: 35px; border-radius: 16px; background: #f8fbff; }
                        input { font-size: 16px; }
                        button { margin-top: 22px; padding: 13px 28px; background: #2878d8; color: white; border: none; border-radius: 10px; font-size: 16px; cursor: pointer; }
                        button:hover { background: #155fae; }
                        .small { color: #555; font-size: 14px; }
                    </style>
                </head>
                <body>
                    <div class="box">
                        <h1>AI Internet Similar Image Searcher</h1>
                        <p>Upload an image. AI detects the topic, then classical algorithms rank internet images.</p>
                        <form action="/search" method="post" enctype="multipart/form-data">
                            <div class="drop">
                                <input type="file" name="image" accept="image/*" required>
                            </div>
                            <button type="submit">Search Similar Images</button>
                        </form>
                        <p class="small">Algorithm backbone: HashMap + Edit Distance Dynamic Programming + MinHeap.</p>
                    </div>
                </body>
                </html>
                """;
    }

    private static String resultsPage(String topic, List<ImageResult> images) {
        StringBuilder html = new StringBuilder();
        html.append("""
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Results</title>
                    <style>
                        body { font-family: Arial; background: #f4f4f4; text-align: center; }
                        .card { background: white; display: inline-block; width: 280px; min-height: 310px; margin: 15px; padding: 15px; border-radius: 12px; box-shadow: 0 0 10px rgba(0,0,0,0.2); vertical-align: top; }
                        img { width: 250px; height: 175px; object-fit: cover; border-radius: 10px; }
                        a { margin: 20px; display: inline-block; }
                        h3 { font-size: 15px; word-break: break-word; }
                    </style>
                </head>
                <body>
                    <h1>Similar Images From Internet</h1>
                """);

        html.append("<h2>AI detected topic: ").append(escape(topic)).append("</h2>");
        html.append("<a href='/'>Search Again</a><br>");

        if (images.isEmpty()) {
            html.append("<h2>No internet images found. Try another image.</h2>");
        }

        for (ImageResult image : images) {
            html.append("""
                    <div class="card">
                        <img src="%s" alt="result image">
                        <h3>%s</h3>
                        <p>Edit Distance Score: %d</p>
                    </div>
                    """.formatted(image.imageUrl, escape(image.title), image.score));
        }

        html.append("</body></html>");
        return html.toString();
    }

    private static String escape(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
